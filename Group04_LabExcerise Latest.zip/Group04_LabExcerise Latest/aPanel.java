 // apanel is as Image panel
 // shortterm to code 
import javax.swing.*;
import java.awt.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.geom.AffineTransform;
import java.util.ArrayList;
import java.util.List;

public class aPanel extends JPanel {
    private List<ImageEntry> images;
    private int currentRow = 0;

    private class ImageEntry {// For initial images
        ImageIcon image;
        int x, y;
        double angle;
        // JTable for Image Entry //https://www.geeksforgeeks.org/java-swing-jtable/ 


        ImageEntry(ImageIcon image, int x, int y) {
            this.image = image;
            this.x = x;
            this.y = y;
            this.angle = 0;
        }

        Rectangle getBounds() {
            return new Rectangle(x, y, image.getIconWidth(), image.getIconHeight());
        }
    }

            // panel listern for mouse clicks using a 'MouseListener'
            // Basically when image is clicked, the image rotates by 45 degree. mouseClicked(MouseEvent e) method.

            //https://www.geeksforgeeks.org/mouselistener-mousemotionlistener-java/ 
    public aPanel() {
        images = new ArrayList<>();
        setPreferredSize(new Dimension(800, 800));

        addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                for (ImageEntry entry : images) {
                    if (entry.getBounds().contains(e.getPoint())) {
                        entry.angle += Math.toRadians(45); // Rotate 45 degrees on each click
                        repaint();
                        return;
                    }
                }
            }
        });
    }

    public void addAnimalImage(String filePath) {
        ImageIcon icon = new ImageIcon(filePath);
        if (icon.getIconWidth() == -1) {
            JOptionPane.showMessageDialog(this, "Image not found or unable to load: " + filePath, "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        int xOffset = 5;
        int yOffset = currentRow * icon.getIconHeight();
        
        images.add(new ImageEntry(icon, xOffset, yOffset));
        
        // Increment row only when both an animal and a flower are added
        if (images.size() % 2 == 0) {
            currentRow++;
        }
        
        repaint();
    }

    public void addFlowerImage(String filePath) {
        ImageIcon icon = new ImageIcon(filePath);
        if (icon.getIconWidth() == -1) {
            JOptionPane.showMessageDialog(this, "Image not found or unable to load: " + filePath, "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        int xOffset = 550; // Offset by 200 pixels to place next to the animal image
        int yOffset = currentRow * icon.getIconHeight();

        images.add(new ImageEntry(icon, xOffset, yOffset));

        // Increment row only when both an animal and a flower are added
        if (images.size() % 2 == 0) {
            currentRow++;
        }

        repaint();
    }
    
    // create image to rotated 

    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        Graphics2D g2d = (Graphics2D) g;

        for (ImageEntry entry : images) {
            drawRotatedImage(g2d, entry);
        }
    }
    // this the input parameters - graphichg2d -ImageEntry entry 
    // calculation the center point of image center x / half of the image width for split
    // this i use w3school to learn . 

    private void drawRotatedImage(Graphics2D g2d, ImageEntry entry) {
        int imageWidth = entry.image.getIconWidth();
        int imageHeight = entry.image.getIconHeight();
        int centerX = entry.x + imageWidth / 2;
        int centerY = entry.y + imageHeight / 2;

        AffineTransform oldTransform = g2d.getTransform();
        AffineTransform transform = new AffineTransform();
        transform.rotate(entry.angle, centerX, centerY);
        transform.translate(entry.x, entry.y);

        g2d.setTransform(transform);
        g2d.drawImage(entry.image.getImage(), 0, 0, this);
        g2d.setTransform(oldTransform); // Reset the transform
    }
}

