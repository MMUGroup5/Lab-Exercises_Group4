// bpanel is as drawing panel
// shortterm to code 


import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
// import java.awt.geom.AffineTransform;
import java.awt.image.BufferedImage;
import java.io.File;
import javax.imageio.ImageIO;
import java.io.IOException;

public class bPanel extends JPanel {
    private BufferedImage canvas;
    private Graphics2D g2;
    private Color penColor;
    private int penSize;
    private double rotationAngle; // New variable to store rotation angle

    public bPanel() {
        canvas = new BufferedImage(400, 600, BufferedImage.TYPE_INT_ARGB);
        g2 = canvas.createGraphics();
        g2.setColor(Color.YELLOW); // Set background color to yellow
        g2.fillRect(0, 0, canvas.getWidth(), canvas.getHeight());
        g2.setColor(Color.BLACK);
        penColor = Color.BLACK;
        penSize = 1;
        rotationAngle = 0; // Initialize rotation angle to 0
        setPreferredSize(new Dimension(600, 600));
        setDoubleBuffered(false);

        addMouseListener(new MouseAdapter() {
            public void mousePressed(MouseEvent e) {
                draw(e.getX(), e.getY());
            }
        });

        addMouseMotionListener(new MouseMotionAdapter() {
            public void mouseDragged(MouseEvent e) {
                draw(e.getX(), e.getY());
            }
        });
    }

    private void draw(int x, int y) {
        g2.setColor(penColor);
        g2.fillOval(x - penSize / 2, y - penSize / 2, penSize, penSize);
        repaint();
    }

    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);

        // Apply rotation transformation
        Graphics2D g2d = (Graphics2D) g.create();
        g2d.rotate(rotationAngle, getWidth() / 2.0, getHeight() / 2.0);
        
        g2d.drawImage(canvas, 0, 0, null);
        g2d.dispose();
    }

    public void setPenColor(Color newColor) {
        penColor = newColor;
    }

    public void setPenSize(int newSize) {
        penSize = newSize;
    }

    // Method to set rotation angle
    public void setRotationAngle(double angle) {
        rotationAngle = angle;
        repaint(); // Repaint after setting rotation angle
    }

    // to save the drawing in visual code directly.
    public void saveDrawing() {
        try {
            ImageIO.write(canvas, "PNG", new File("drawing.png"));
            JOptionPane.showMessageDialog(this, "Drawing saved successfully!");
        } catch (IOException ex) {
            JOptionPane.showMessageDialog(this, "Error saving drawing!", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }
}


    // to save the drawing in visua code directly. 
    
//     public void saveDrawing() {
//         try {
//             ImageIO.write(canvas, "PNG", new File("drawing.png"));
//             JOptionPane.showMessageDialog(this, "Drawing saved successfully!");
//         } catch (IOException ex) {
//             JOptionPane.showMessageDialog(this, "Error saving drawing!", "Error", JOptionPane.ERROR_MESSAGE);
//         }
//     }
// }
