// // // apanel is as Image panel
// // // shortterm to code 

// // import javax.swing.*;
// // import java.awt.*;
// // import java.awt.event.MouseAdapter;
// // import java.awt.event.MouseEvent;
// // import java.awt.geom.AffineTransform;
// // import java.util.ArrayList;
// // import java.util.List;

// // public class aPanel extends JPanel {
// //     private class ImageEntry {
// //         ImageIcon image;
// //         double angle;
// //         int x, y;

// //         ImageEntry(ImageIcon image, int x, int y) {
// //             this.image = image;
// //             this.angle = 0;
// //             this.x = x;
// //             this.y = y;
// //         }

// //         Rectangle getBounds() {
// //             return new Rectangle(x, y, image.getIconWidth(), image.getIconHeight());
// //         }
// //     }

// //     private List<ImageEntry> firstTable; // For initial images
// //     private List<ImageEntry> secondTable; // For images added later - // need to ask sir about this 
// //         // JTable for Image Entry //https://www.geeksforgeeks.org/java-swing-jtable/ 

// //     public aPanel() {
// //         firstTable = new ArrayList<>();
// //         secondTable = new ArrayList<>();
// //         setPreferredSize(new Dimension(400, 600));

// //             // panel listern for mouse clicks using a 'MouseListener'
// //             // Basically when image is clicked, the image rotates by 45 degree. mouseClicked(MouseEvent e) method.

// //             //https://www.geeksforgeeks.org/mouselistener-mousemotionlistener-java/ 

// //         addMouseListener(new MouseAdapter() {
// //             @Override
// //             public void mouseClicked(MouseEvent e) {
// //                 boolean clicked = false;
// //                 for (ImageEntry entry : firstTable) {
// //                     if (entry.getBounds().contains(e.getPoint())) {
// //                         entry.angle += Math.toRadians(45);  // Rotate 45 degrees on each click
// //                         clicked = true;
// //                         break;
// //                     }
// //                 }
// //                 if (!clicked) {
// //                     for (ImageEntry entry : secondTable) {
// //                         if (entry.getBounds().contains(e.getPoint())) {
// //                             entry.angle += Math.toRadians(45);  // Rotate 45 degrees on each click
// //                             break;
// //                         }
// //                     }
// //                 }
// //                 repaint();
// //             }
// //         });
// //     }

// //     public void addAnimalImage(String filePath) {
// //         ImageIcon icon = new ImageIcon(filePath);
// //         if (icon.getIconWidth() == -1) {
// //             JOptionPane.showMessageDialog(this, "Image not found or unable to load: " + filePath, "Error", JOptionPane.ERROR_MESSAGE);
// //             return;
// //         }
// //         firstTable.add(new ImageEntry(icon, 0, firstTable.size() *250));  // Position each new image 100 pixels below the previous one
// //         repaint();
// //     }

// //     public void addFlowerImage(String filePath) {
// //         ImageIcon icon = new ImageIcon(filePath);
// //         if (icon.getIconWidth() == -1) {
// //             JOptionPane.showMessageDialog(this, "Image not found or unable to load: " + filePath, "Error", JOptionPane.ERROR_MESSAGE);
// //             return;
// //         }
// //         firstTable.add(new ImageEntry(icon, 200, firstTable.size() * 250));  // Position each new image 100 pixels below the previous one
// //         repaint();
// //     }

// //     public void addAnimalImageToSecondTable(String filePath) {
// //         ImageIcon icon = new ImageIcon(filePath);
// //         if (icon.getIconWidth() == -1) {
// //             JOptionPane.showMessageDialog(this, "Image not found or unable to load: " + filePath, "Error", JOptionPane.ERROR_MESSAGE);
// //             return;
// //         }
// //         secondTable.add(new ImageEntry(icon, 0, secondTable.size() * 250));  // Position each new image 100 pixels below the previous one
// //         repaint();
// //     }

// //     public void addFlowerImageToSecondTable(String filePath) {
// //         ImageIcon icon = new ImageIcon(filePath);
// //         if (icon.getIconWidth() == -1) {
// //             JOptionPane.showMessageDialog(this, "Image not found or unable to load: " + filePath, "Error", JOptionPane.ERROR_MESSAGE);
// //             return;
// //         }
// //         secondTable.add(new ImageEntry(icon, 200, secondTable.size() * 250));  // Position each new image 100 pixels below the previous one
// //         repaint();
// //     }
// //         // create image to rotated 
// //     @Override
// //     protected void paintComponent(Graphics g) {
// //         super.paintComponent(g);
// //         Graphics2D g2d = (Graphics2D) g;

// //         for (ImageEntry entry : firstTable) {
// //             drawRotatedImage(g2d, entry);
// //         }
// //         for (ImageEntry entry : secondTable) {
// //             drawRotatedImage(g2d, entry);
// //         }
// //     }

// //     // this the input parameters - graphichg2d -ImageEntry entry 
// //     // calculation the center point of image center x / half of the image width for split
// //     // this i use w3school to learn . 

// //     private void drawRotatedImage(Graphics2D g2d, ImageEntry entry) {
// //         int imageWidth = entry.image.getIconWidth();
// //         int imageHeight = entry.image.getIconHeight();
// //         int centerX = entry.x + imageWidth / 2;
// //         int centerY = entry.y + imageHeight / 2;

// //         AffineTransform oldTransform = g2d.getTransform();
// //         AffineTransform transform = new AffineTransform();
// //         transform.rotate(entry.angle, centerX, centerY);
// //         transform.translate(entry.x, entry.y);

// //         g2d.setTransform(transform);
// //         g2d.drawImage(entry.image.getImage(), 0, 0, this);
// //         g2d.setTransform(oldTransform);  // Reset the transform
// //     }
// // }

// import javax.swing.*;
// import java.awt.*;
// import java.awt.event.MouseAdapter;
// import java.awt.event.MouseEvent;
// import java.util.ArrayList;
// import java.util.List;

// public class aPanel extends JPanel {
//     private List<ImageEntry> animalImages;
//     private List<ImageEntry> flowerImages;

//     private enum ImageType {
//         ANIMAL, FLOWER
//     }

//     private class ImageEntry {
//         ImageIcon image;
//         int x, y;
//         @SuppressWarnings("unused")
//         ImageType type;

//         ImageEntry(ImageIcon image, int x, int y, ImageType type) {
//             this.image = image;
//             this.x = x;
//             this.y = y;
//             this.type = type;
//         }

//         Rectangle getBounds() {
//             return new Rectangle(x, y, image.getIconWidth(), image.getIconHeight());
//         }
//     }

//     public aPanel() {
//         animalImages = new ArrayList<>();
//         flowerImages = new ArrayList<>();
//         setPreferredSize(new Dimension(400, 600));

//         addMouseListener(new MouseAdapter() {
//             @Override
//             public void mouseClicked(MouseEvent e) {
//                 for (ImageEntry entry : animalImages) {
//                     if (entry.getBounds().contains(e.getPoint())) {
//                         // Flip animal image
//                         entry.image = flipImage(entry.image);
//                         repaint();
//                         return;
//                     }
//                 }
//                 for (ImageEntry entry : flowerImages) {
//                     if (entry.getBounds().contains(e.getPoint())) {
//                         // Scale flower image
//                         entry.image = scaleImage(entry.image);
//                         repaint();
//                         return;
//                     }
//                 }
//             }
//         });
//     }

//     public void addAnimalImage(String filePath) {
//         ImageIcon icon = new ImageIcon(filePath);
//         if (icon.getIconWidth() == -1) {
//             JOptionPane.showMessageDialog(this, "Image not found or unable to load: " + filePath, "Error", JOptionPane.ERROR_MESSAGE);
//             return;
//         }
//         animalImages.add(new ImageEntry(icon, 0, animalImages.size() * 500, ImageType.ANIMAL));  // Position each new image 100 pixels below the previous one
//         repaint();
//     }

//     public void addFlowerImage(String filePath) {
//         ImageIcon icon = new ImageIcon(filePath);
//         if (icon.getIconWidth() == -1) {
//             JOptionPane.showMessageDialog(this, "Image not found or unable to load: " + filePath, "Error", JOptionPane.ERROR_MESSAGE);
//             return;
//         }
//         int flowerSpacing = 20; // Adjust this value to increase/decrease spacing between flower images
//         int xOffset = 200 + (icon.getIconWidth() + flowerSpacing) * flowerImages.size(); // Calculate x-coordinate for the new flower image

//         //this shit 
//         flowerImages.add(new ImageEntry(icon, xOffset, -500, ImageType.FLOWER));  // Position each new image horizontally next to the previous one
//         repaint();
//     }
    
    

//     @Override
//     protected void paintComponent(Graphics g) {
//         super.paintComponent(g);

//         Graphics2D g2d = (Graphics2D) g;
//         for (ImageEntry entry : animalImages) {
//             entry.image.paintIcon(this, g2d, entry.x, entry.y);
//         }
//         for (ImageEntry entry : flowerImages) {
//             entry.image.paintIcon(this, g2d, entry.x, entry.y);
//         }
//     }

//     private ImageIcon flipImage(ImageIcon icon) {
//         // You need to implement flipping logic here
//         return icon; // Dummy implementation
//     }

//     private ImageIcon scaleImage(ImageIcon icon) {
//         // You need to implement scaling logic here
//         return icon; // Dummy implementation
//     }
// }
import javax.swing.*;
import java.awt.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.geom.AffineTransform;
import java.util.ArrayList;
import java.util.List;

public class aPanel extends JPanel {
    private List<ImageEntry> images;
    private int currentRow = 0;

    private class ImageEntry {
        ImageIcon image;
        int x, y;
        double angle;

        ImageEntry(ImageIcon image, int x, int y) {
            this.image = image;
            this.x = x;
            this.y = y;
            this.angle = 0;
        }

        Rectangle getBounds() {
            return new Rectangle(x, y, image.getIconWidth(), image.getIconHeight());
        }
    }

    public aPanel() {
        images = new ArrayList<>();
        setPreferredSize(new Dimension(800, 800));

        addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                for (ImageEntry entry : images) {
                    if (entry.getBounds().contains(e.getPoint())) {
                        entry.angle += Math.toRadians(45); // Rotate 45 degrees on each click
                        repaint();
                        return;
                    }
                }
            }
        });
    }

    public void addAnimalImage(String filePath) {
        ImageIcon icon = new ImageIcon(filePath);
        if (icon.getIconWidth() == -1) {
            JOptionPane.showMessageDialog(this, "Image not found or unable to load: " + filePath, "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        int xOffset = 0;
        int yOffset = currentRow * icon.getIconHeight();
        
        images.add(new ImageEntry(icon, xOffset, yOffset));
        
        // Increment row only when both an animal and a flower are added
        if (images.size() % 2 == 0) {
            currentRow++;
        }
        
        repaint();
    }

    public void addFlowerImage(String filePath) {
        ImageIcon icon = new ImageIcon(filePath);
        if (icon.getIconWidth() == -1) {
            JOptionPane.showMessageDialog(this, "Image not found or unable to load: " + filePath, "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        int xOffset = 200; // Offset by 200 pixels to place next to the animal image
        int yOffset = currentRow * icon.getIconHeight();

        images.add(new ImageEntry(icon, xOffset, yOffset));

        // Increment row only when both an animal and a flower are added
        if (images.size() % 2 == 0) {
            currentRow++;
        }

        repaint();
    }

    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        Graphics2D g2d = (Graphics2D) g;

        for (ImageEntry entry : images) {
            drawRotatedImage(g2d, entry);
        }
    }

    private void drawRotatedImage(Graphics2D g2d, ImageEntry entry) {
        int imageWidth = entry.image.getIconWidth();
        int imageHeight = entry.image.getIconHeight();
        int centerX = entry.x + imageWidth / 2;
        int centerY = entry.y + imageHeight / 2;

        AffineTransform oldTransform = g2d.getTransform();
        AffineTransform transform = new AffineTransform();
        transform.rotate(entry.angle, centerX, centerY);
        transform.translate(entry.x, entry.y);

        g2d.setTransform(transform);
        g2d.drawImage(entry.image.getImage(), 0, 0, this);
        g2d.setTransform(oldTransform); // Reset the transform
    }
}

